package main

import (
	"fmt"
	"time"

	"github.com/lazybark/go-helpers/npt"
)

func main() {
	//Calling Now() will create a new NPT from current moment in time
	t := npt.Now()
	fmt.Println("Now it's:", t.Time())
	//ToNow will set internals of NPT to current moment
	time.Sleep(2 * time.Second)
	t.ToNow()
	fmt.Println("And now it's:", t.Time())
	//FromTime() will set NPT to specified time value
	t.FromTime(time.Now().Add(time.Hour))
	fmt.Println("And now it's:", t.Time())
	//Add() will add specified duration to NPT
	t.Add(time.Hour)
	fmt.Println("And now it's:", t.Time())
	//Time() will return time.Time object from NPT internals
	gt := t.Time()
	fmt.Println("And now it's:", gt)
}
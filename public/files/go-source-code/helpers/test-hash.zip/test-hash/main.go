package main

import (
  "fmt"
  "github.com/lazybark/go-helpers/hasher"
)

func main() {
  // Get & print all types of file hash
  SHA256, err := hasher.HashFilePath("example_file", hasher.SHA256, 8192)
  if err != nil {
    fmt.Println(err)
  }
  MD5, err := hasher.HashFilePath("example_file", hasher.MD5, 8192)
  if err != nil {
    fmt.Println(err)
  }
  SHA1, err := hasher.HashFilePath("example_file", hasher.SHA1, 8192)
  if err != nil {
    fmt.Println(err)
  }
  SHA512, err := hasher.HashFilePath("example_file", hasher.SHA512, 8192)
  if err != nil {
    fmt.Println(err)
  }

  fmt.Println("File hashes:")
  fmt.Println(SHA256)
  fmt.Println(MD5)
  fmt.Println(SHA1)
  fmt.Println(SHA512)
  
  // Hash string
  s := "Some string for you"
  fmt.Printf("String hashes ('%s'):\n", s)
  fmt.Println(hasher.HashString(s, hasher.SHA256))
  fmt.Println(hasher.HashString(s, hasher.MD5))
  fmt.Println(hasher.HashString(s, hasher.SHA1))
  fmt.Println(hasher.HashString(s, hasher.SHA512))
  
  // Hash bytes
  fmt.Println("[]byte hashes:")
  b := []byte(s)
  fmt.Println(hasher.HashBytes(b, hasher.SHA256))
  fmt.Println(hasher.HashBytes(b, hasher.MD5))
  fmt.Println(hasher.HashBytes(b, hasher.SHA1))
  fmt.Println(hasher.HashBytes(b, hasher.SHA512))
}
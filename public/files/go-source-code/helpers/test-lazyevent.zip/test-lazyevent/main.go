package main

import (
	"fmt"
	"log"
	"time"

	"github.com/lazybark/go-helpers/events/le"
)

func main() {
	//Create new processor with desired number of events to keep in chain
	p := le.NewV1(3)
	//Add loggers for CLI or console
	err := p.NewConsole()
	if err != nil {
		log.Fatal(err)
	}
	err = p.NewFile("log.txt", true)
	if err != nil {
		log.Fatal(err)
	}
	//Create event sources if needed
	srcE := p.Source("EXTRA", "cyan", "[", "]")
	srcS := p.Source("SOMESTUFF", "red", "[", "]")
	//Create events
	e1 := srcE.Event(p, "Event 1")
	time.Sleep(time.Second)
	e2 := srcS.Info(p, "Event 2")
	time.Sleep(time.Second)
	e3 := p.Event("Event 3")
	time.Sleep(time.Second)
	e4 := p.Warning("Event 4")
	//Modify events
	e1.Append(" more text")
	e2 = e2.Blue()
	e3.BgGreenSet()
	e4 = e4.BgCyan().ConsoleOnly().Note()
	//Log events
	e1.Log()
	e2.Log()
	e3.Log()
	e4.Log()
	p.Error("That's an error").Src(srcS).BgRed().Log()
	time.Sleep(2 * time.Second)
	//Get chain of events
	fmt.Println("Events chain:")
	c := *p.EventChain()
	for _, e := range c {
		fmt.Printf("%s:%s\n", e.Time, e.Text)
	}
}
